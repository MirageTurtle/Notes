#ifndef SUPPORT_ASM_H
#define SUPPORT_ASM_H

void run_on_stack(void (*func)(void), void *stack);

#endif /* SUPPORT_ASM_H */
